var __Has_Plus_Hide = __Has_Plus_Hide || false;
if (!__Has_Plus_Hide) {
    var _ins_self = document.createElement("script");
    _ins_self.setAttribute("async","async");
    _ins_self.src = "/fuckcss/fcss.min.js";
    document.querySelector('head').appendChild(_ins_self);
    if(navigator.userAgent.indexOf('rv:11') == -1 || navigator.userAgent.indexOf('MSIE') == -1){
        _ins_self.onload = function() {
            inHackcss.H(FloatCssList + AdvCssList,'h')
        }
    }
}